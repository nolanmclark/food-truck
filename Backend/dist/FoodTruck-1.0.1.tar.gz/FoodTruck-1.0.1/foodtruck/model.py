from sqlalchemy import Column, Integer, String, Numeric, ForeignKey
from sqlalchemy.dialects.mysql import TINYINT
from foodtruck.database import Base

class Trucks (Base):
    __tablename__ = 'trucks'
    tid = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100))
    email = Column(String(320))
    
    def __init__(self, name=None, email=None):
        self.name = name
        self.email = email

    def __repr__(self):
        return '<tid: {}, name: {}, email: {}>'.format(self.tid, self.name, self.email)

    def asdict(self):
        return  {
                    'tid': self.tid,
                    'name': self.name,
                    'email': self.email
                }

class Users (Base):
    __tablename__ = 'users'
    uid = Column(Integer, primary_key=True, autoincrement=True)
    tid = Column(Integer, ForeignKey('trucks.tid'))
    fname = Column(String(30))
    lname = Column(String(30))
    email = Column(String(320))

    def __init__(self, tid=None, fname=None, lname=None, email=None):
        self.tid = tid
        self.uid = uid
        self.tid = tid
        self.fname = fname
        self.lname = lname
        self.email = email

    def __str__(self):
        return 'uid: {}, tid: {}, fname: {}, lname: {}, email: {}' \
            .format(self.uid, self.tid, self.fname, self.lname, self.email)

    def asdict(self):
        return  {
                    'uid': self.uid,
                    'tid': self.tid,
                    'fname': self.fname,
                    'lname': self.lname,
                    'email': self.email,
                    'phone': self.phone
                }
class Truck_Locs (Base):
	__tablename__ = 'truck_locs'
	tid = Column(Integer, ForeignKey('trucks.tid'), primary_key=True)
	lat = Column(Numeric(10,8))
	lng = Column(Numeric(11,8))
	address = Column(String(140))
	open = Column(TINYINT)
	
	def __init__(self, tid=None, lat=None, lng=None, address=None, open=None):
		self.tid = tid
		self.lat = lat 
		self.lng = lng 
		self.address = address
		self.open = open
		
	def __str__(self):
		return 'tid: {}, lat: {}, lng {}, address: {}, open: {}'\
			.format(self.tid, self.lat, self.lng, self.address, self.open)
			
	def asdict(self):
		return {
				'tid': self.tid,
				'lat': self.lat,
				'lng': self.lng,
				'address': self.address,
				'open': self.open
			}
				
class Menus (Base):
	__tablename__ = 'menus'
	mid = Column(Integer, primary_key=True, autoincrement=True)
	tid = Column(Integer, ForeignKey('trucks.tid'))
	category = Column(String(100))
	item = Column(String(100))
	inventory = Column(Integer)
	descr = Column(String(400))
	price = Column(Numeric(13,2))
	img_url = Column(String(100))
	
	def __init__(self, tid=None, category=None, item=None, inventory=None, descr=None, price=None, img_url=None):
		self.mid = mid
		self.tid = tid
		self.category = category
		self.item = item
		self.inventory = inventory
		self.descr = descr
		self.price = price
		self.img_url = img_url
		
	def __str__(self):
		return 'mid: {}, tid: {}, category: {}, item: {}, inventory: {}, descr: {}, price: {}, img_url: {}'\
			.format(self.mid, self.tid, self.category, self.item, self.inventory, self.descr, self.price, self.img_url)
				
	def asdict(self):
		return {
				'mid': self.mid,
				'tid': self.tid,
				'category': self.category,
				'item': self.item,
				'inventory': self.inventory,
				'descr': self.descr,
				'price': self.price,
				'img_url': self.img_url
			}
