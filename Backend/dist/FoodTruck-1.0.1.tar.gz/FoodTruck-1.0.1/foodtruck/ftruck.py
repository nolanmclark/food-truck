from flask import Flask, Response
import logging
from logging.config import fileConfig
import json
from foodtruck.database import Session
import functions

LOG_FILE = os.environ['FOODTRUCK_API_LOG_CONFIG']
fileConfig(LOG_FILE + 'logging.ini')
logger = logging.getLogger()

app = Flask(__name__)


@app.teardown_appcontext
def shutdown_session(exception=None):
    Session.remove()


@app.before_request
def before_request():
    logger.info("[%s] - %s" % (request.method, request.endpoint))
    return


@app.route('/')
def index():
    return Response(json.dumps({'check': 'one two'}))


@app.route('/trucks', methods=['GET'])
def all_trucks():
    return Response(functions.all_trucks())


@app.after_request
def after_request(response):
    response.headers['Content-Type'] = 'application/json'
    return response


if __name__ == '__main__':
    app.run(debug=False)
