import os
from flask import Flask, Response, request
import logging
import logging.config
import json
from foodtruck.database import Session
import functions

LOG_FILE = os.environ['FOODTRUCK_API_LOG_INI']
logging.config.fileConfig(LOG_FILE, disable_existing_loggers=False)
logger = logging.getLogger()

app = Flask(__name__)


@app.teardown_appcontext
def shutdown_session(exception=None):
    Session.remove()


@app.route('/')
def index():
    logger.info("[%s] - %s" % (request.method, request.path))
    return Response(json.dumps({'check': 'one two'}))


@app.route('/trucks', methods=['GET'])
def all_trucks():
    logger.info("[%s] - %s" % (request.method, request.path))
    return Response(functions.all_trucks())


@app.route('/locations', methods=['GET'])
def all_locations():
    logger.info("[%s] - %s" % (request.method, request.path))
    return Response(functions.all_locations())


@app.route('/users', methods=['GET'])
def all_users():
    logger.info("[%s] - %s" % (request.method, request.path))
    return Response(functions.all_users())


@app.after_request
def after_request(response):
    response.headers['Content-Type'] = 'application/json'
    response.headers['Access-Control-Allow-Origin'] = '*'
    return response


if __name__ == '__main__':
    app.run(debug=False)
