import os
from foodtruck.database import Session
from foodtruck.model import *
import simplejson as json
import logging
import logging.config
from pprint import pprint

LOG_FILE = os.environ['FOODTRUCK_API_LOG_INI']
logging.config.fileConfig(LOG_FILE, disable_existing_loggers=False)
logger = logging.getLogger()


def all_trucks():
    trucks = [x.asdict() for x in Trucks.query.all()]
    return json.dumps(trucks)


def all_locations():
    #locs = [x.asdict() for x in Truck_Locs.query.all()]
    #locs = Session.query(Trucks.tid, Trucks.name, Truck_Locs.lat, Truck_Locs.lng, Truck_Locs.address, Truck_Locs.open) \
    #    .filter(Trucks.tid == Truck_Locs.tid).all()
    locs = [x.asdict() for x in Truck_Location.query.all()]
    logger.info(locs)
    return json.dumps(locs)


def all_users():
    users = [x.asdict() for x in Users.query.all()]
    return json.dumps(users)

'''
class Truck_Location:
    def __init__(self, tid=None, name=None, lat=None, lng=None, address=None, open=None):
        self.tid = tid
        self.name = name
        self.lat = lat 
        self.lng = lng 
        self.address = address
        self.open = open

    def __str__(self):
        return 'tid: {}, name: {}, lat: {}, lng {}, address: {}, open: {}'\
            .format(self.tid, self.name, self.lat, self.lng, self.address, self.open)

    def asdict(self):
        return {
            'tid': self.tid,
            'name': self.name,
            'lat': self.lat,
            'lng': self.lng,
            'address': self.address,
            'open': self.open
        }
'''
